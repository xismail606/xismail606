package main

import (
	"bufio"
	"flag"
	"fmt"
	"os"
	"strings"
	"time"

	"subtool/internal/analyzer"
	"subtool/internal/cleaner"
	"subtool/internal/filter"
	"subtool/internal/reader"
	"subtool/internal/stats"
	"subtool/internal/writer"
)

const (
	colorReset  = "\033[0m"
	colorRed    = "\033[31m"
	colorGreen  = "\033[32m"
	colorYellow = "\033[33m"
	colorBlue   = "\033[34m"
	colorCyan   = "\033[36m"
)

type Config struct {
	InputFile     string
	OutputFile    string
	Mode          string
	Verbose       bool
	Quiet         bool
	NoColor       bool
	Format        string
	IncludeWords  string
	ExcludeWords  string
	MinLength     int
	MaxLength     int
	TLDFilter     string
	RemoveWildcard bool
	MergeFiles    bool
}

func main() {
	config := parseFlags()

	if err := run(config); err != nil {
		printError(config, "Error: %v\n", err)
		os.Exit(1)
	}
}

func parseFlags() *Config {
	config := &Config{}

	flag.StringVar(&config.InputFile, "i", "", "Input file (use - for stdin)")
	flag.StringVar(&config.OutputFile, "o", "", "Output file (use - for stdout)")
	flag.StringVar(&config.Mode, "mode", "clean", "Operation mode: clean|filter|analyze")
	flag.BoolVar(&config.Verbose, "v", false, "Verbose output")
	flag.BoolVar(&config.Quiet, "q", false, "Quiet mode (minimal output)")
	flag.BoolVar(&config.NoColor, "no-color", false, "Disable colored output")
	flag.StringVar(&config.Format, "format", "txt", "Output format: txt|json|csv")
	flag.StringVar(&config.IncludeWords, "include", "", "Include only subdomains containing these words (comma-separated)")
	flag.StringVar(&config.ExcludeWords, "exclude", "", "Exclude subdomains containing these words (comma-separated)")
	flag.IntVar(&config.MinLength, "min-length", 0, "Minimum subdomain length")
	flag.IntVar(&config.MaxLength, "max-length", 0, "Maximum subdomain length (0 = no limit)")
	flag.StringVar(&config.TLDFilter, "tld", "", "Filter by TLD (comma-separated, e.g., com,net,org)")
	flag.BoolVar(&config.RemoveWildcard, "no-wildcard", false, "Remove wildcard entries")
	flag.BoolVar(&config.MergeFiles, "merge", false, "Merge multiple input files (space-separated)")

	flag.Usage = printUsage
	flag.Parse()

	// Handle remaining args as input files for merge mode
	if config.MergeFiles && flag.NArg() > 0 {
		config.InputFile = strings.Join(flag.Args(), " ")
	}

	return config
}

func printUsage() {
	fmt.Printf(`%sSubdomain Toolkit%s - Fast CLI tool for cleaning, filtering, and analyzing subdomains

%sUSAGE:%s
  subtool -mode <mode> -i <input> -o <output> [options]

%sMODES:%s
  clean     - Remove duplicates, normalize, and sort subdomains
  filter    - Apply advanced filtering rules
  analyze   - Perform statistical analysis and grouping

%sGENERAL OPTIONS:%s
  -i <file>         Input file (use '-' for stdin)
  -o <file>         Output file (use '-' for stdout)
  -mode <mode>      Operation mode (default: clean)
  -format <fmt>     Output format: txt|json|csv (default: txt)
  -v                Verbose output
  -q                Quiet mode
  -no-color         Disable colored output

%sFILTER OPTIONS:%s
  -include <words>  Include only domains with these keywords (comma-separated)
  -exclude <words>  Exclude domains with these keywords (comma-separated)
  -min-length <n>   Minimum domain length
  -max-length <n>   Maximum domain length
  -tld <list>       Filter by TLD (comma-separated: com,net,org)
  -no-wildcard      Remove wildcard entries (*.example.com)
  -merge            Merge multiple input files

%sEXAMPLES:%s
  # Clean and deduplicate
  subtool -mode clean -i domains.txt -o clean.txt

  # Filter by keywords
  subtool -mode filter -i domains.txt -o filtered.txt -include api,dev

  # Analyze and export to JSON
  subtool -mode analyze -i domains.txt -format json -o report.json

  # Pipeline usage
  cat domains.txt | subtool -mode clean -i - -o -

  # Merge and clean multiple files
  subtool -mode clean -merge file1.txt file2.txt file3.txt -o merged.txt

`, colorCyan, colorReset, colorYellow, colorReset, colorYellow, colorReset, colorYellow, colorReset, colorYellow, colorReset, colorYellow, colorReset)
}

func run(config *Config) error {
	startTime := time.Now()

	// Validate input
	if config.InputFile == "" {
		return fmt.Errorf("input file required (use -i flag or -i - for stdin)")
	}

	printInfo(config, "Starting Subdomain Toolkit - Mode: %s\n", config.Mode)

	// Read input
	var domains []string
	var err error

	if config.MergeFiles {
		files := strings.Fields(config.InputFile)
		printInfo(config, "Merging %d files...\n", len(files))
		domains, err = reader.ReadMultipleFiles(files, config.Verbose)
	} else {
		domains, err = reader.ReadDomains(config.InputFile)
	}

	if err != nil {
		return fmt.Errorf("failed to read input: %w", err)
	}

	printInfo(config, "Read %d lines\n", len(domains))

	// Initialize statistics
	statistics := stats.NewStats()
	statistics.TotalLines = len(domains)

	// Process based on mode
	var result []string

	switch config.Mode {
	case "clean":
		result = processCleaner(domains, statistics, config)
	case "filter":
		result = processFilter(domains, statistics, config)
	case "analyze":
		return processAnalyzer(domains, statistics, config)
	default:
		return fmt.Errorf("unknown mode: %s (use clean, filter, or analyze)", config.Mode)
	}

	// Write output
	if err := writer.Write(config.OutputFile, result, config.Format); err != nil {
		return fmt.Errorf("failed to write output: %w", err)
	}

	// Print statistics
	if !config.Quiet {
		statistics.Duration = time.Since(startTime)
		printStatistics(config, statistics)
	}

	printSuccess(config, "✓ Processing complete!\n")
	return nil
}

func processCleaner(domains []string, statistics *stats.Stats, config *Config) []string {
	printInfo(config, "Cleaning subdomains...\n")

	cleaned := cleaner.Clean(domains, statistics, config.Verbose)

	printInfo(config, "Cleaned: %d unique subdomains\n", len(cleaned))
	return cleaned
}

func processFilter(domains []string, statistics *stats.Stats, config *Config) []string {
	printInfo(config, "Applying filters...\n")

	filterConfig := &filter.Config{
		IncludeWords:   strings.Split(config.IncludeWords, ","),
		ExcludeWords:   strings.Split(config.ExcludeWords, ","),
		MinLength:      config.MinLength,
		MaxLength:      config.MaxLength,
		TLDs:           strings.Split(config.TLDFilter, ","),
		RemoveWildcard: config.RemoveWildcard,
	}

	// Clean filters
	if config.IncludeWords == "" {
		filterConfig.IncludeWords = nil
	}
	if config.ExcludeWords == "" {
		filterConfig.ExcludeWords = nil
	}
	if config.TLDFilter == "" {
		filterConfig.TLDs = nil
	}

	filtered := filter.Apply(domains, filterConfig, statistics, config.Verbose)

	printInfo(config, "Filtered: %d subdomains match criteria\n", len(filtered))
	return filtered
}

func processAnalyzer(domains []string, statistics *stats.Stats, config *Config) error {
	printInfo(config, "Analyzing subdomains...\n")

	analysis := analyzer.Analyze(domains, config.Verbose)

	// Write analysis report
	if err := writer.WriteAnalysis(config.OutputFile, analysis, config.Format); err != nil {
		return fmt.Errorf("failed to write analysis: %w", err)
	}

	// Print summary if not quiet
	if !config.Quiet {
		printAnalysisSummary(config, analysis)
	}

	return nil
}

func printStatistics(config *Config, stats *stats.Stats) {
	if config.Quiet {
		return
	}

	fmt.Printf("\n%s=== STATISTICS ===%s\n", colorCyan, colorReset)
	fmt.Printf("Total lines:        %d\n", stats.TotalLines)
	fmt.Printf("Unique subdomains:  %d\n", stats.UniqueSubdomains)
	fmt.Printf("Duplicates removed: %d\n", stats.DuplicatesRemoved)
	fmt.Printf("Invalid entries:    %d\n", stats.InvalidEntries)
	fmt.Printf("Processing time:    %v\n", stats.Duration)
	fmt.Printf("%s==================%s\n\n", colorCyan, colorReset)
}

func printAnalysisSummary(config *Config, analysis *analyzer.Analysis) {
	fmt.Printf("\n%s=== ANALYSIS SUMMARY ===%s\n", colorCyan, colorReset)
	fmt.Printf("Total subdomains:   %d\n", analysis.TotalSubdomains)
	fmt.Printf("Unique root domains: %d\n", len(analysis.RootDomains))
	fmt.Printf("Max depth level:    %d\n", analysis.MaxDepth)
	fmt.Printf("Avg depth level:    %.2f\n", analysis.AvgDepth)
	fmt.Printf("Top 5 common words:\n")
	for i, word := range analysis.TopWords {
		if i >= 5 {
			break
		}
		fmt.Printf("  %d. %s (%d occurrences)\n", i+1, word.Word, word.Count)
	}
	fmt.Printf("%s=======================%s\n\n", colorCyan, colorReset)
}

func printInfo(config *Config, format string, args ...interface{}) {
	if config.Quiet {
		return
	}
	if config.NoColor {
		fmt.Printf(format, args...)
	} else {
		fmt.Printf(colorBlue+"[*] "+colorReset+format, args...)
	}
}

func printSuccess(config *Config, format string, args ...interface{}) {
	if config.Quiet {
		return
	}
	if config.NoColor {
		fmt.Printf(format, args...)
	} else {
		fmt.Printf(colorGreen+format+colorReset, args...)
	}
}

func printError(config *Config, format string, args ...interface{}) {
	if config.NoColor {
		fmt.Fprintf(os.Stderr, format, args...)
	} else {
		fmt.Fprintf(os.Stderr, colorRed+"[!] "+format+colorReset, args...)
	}
}
