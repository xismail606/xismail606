# Quick Start Guide

## 5-Minute Setup

### 1. Build the Tool

```bash
cd subtool
go build -o subtool cmd/subtool/main.go
```

Or use Make:
```bash
make build
```

### 2. Test with Sample Data

```bash
# Clean mode
./build/subtool -mode clean -i tests/sample_inputs/test-domains.txt -o clean.txt

# Filter mode
./build/subtool -mode filter -i tests/sample_inputs/test-domains.txt -o filtered.txt -include api

# Analyze mode
./build/subtool -mode analyze -i tests/sample_inputs/test-domains.txt -o analysis.txt
```

### 3. Real-World Usage

#### Bug Bounty Workflow

```bash
# Step 1: Collect subdomains from multiple tools
cat amass_output.txt subfinder_output.txt assetfinder_output.txt > all_subdomains.txt

# Step 2: Clean and deduplicate
./subtool -mode clean -i all_subdomains.txt -o clean_subdomains.txt -v

# Step 3: Remove wildcards and test domains
./subtool -mode filter -i clean_subdomains.txt -o production.txt \
  -no-wildcard \
  -exclude test,staging,dev,old

# Step 4: Extract interesting targets
./subtool -mode filter -i production.txt -o high_value_targets.txt \
  -include api,admin,panel,dashboard,portal,login

# Step 5: Analyze the results
./subtool -mode analyze -i high_value_targets.txt -format json -o analysis.json
```

## Common Commands

### Clean Only
```bash
./subtool -mode clean -i domains.txt -o clean.txt
```

### Filter by Keywords
```bash
./subtool -mode filter -i domains.txt -o api-domains.txt -include api,dev
```

### Analyze Dataset
```bash
./subtool -mode analyze -i domains.txt -format json -o report.json
```

### Pipeline Processing
```bash
cat domains.txt | ./subtool -mode clean -i - -o - | ./subtool -mode filter -i - -include prod -o final.txt
```

### Merge Multiple Files
```bash
./subtool -mode clean -merge file1.txt file2.txt file3.txt -o merged.txt
```

## Output Examples

### Clean Mode Output
```
[*] Starting Subdomain Toolkit - Mode: clean
[*] Read 45 lines
[*] Cleaning subdomains...
[*] Cleaned: 32 unique subdomains
✓ Processing complete!

=== STATISTICS ===
Total lines:        45
Unique subdomains:  32
Duplicates removed: 11
Invalid entries:    2
Processing time:    5ms
==================
```

### Filter Mode Output
```
[*] Starting Subdomain Toolkit - Mode: filter
[*] Read 1000 lines
[*] Applying filters...
[*] Filtered: 234 subdomains match criteria
✓ Processing complete!

=== STATISTICS ===
Total lines:        1000
Unique subdomains:  234
Duplicates removed: 0
Invalid entries:    15
Processing time:    12ms
==================
```

### Analyze Mode Output
```
=== SUBDOMAIN ANALYSIS REPORT ===

OVERVIEW
Total Subdomains: 1,234
Unique Root Domains: 15
Max Depth Level: 4
Average Depth: 2.45

TOP 10 ROOT DOMAINS BY SUBDOMAIN COUNT
1. example.com (678 subdomains)
2. test.com (234 subdomains)
3. demo.org (156 subdomains)

DEPTH DISTRIBUTION
Depth 1: 45 domains
Depth 2: 567 domains
Depth 3: 456 domains
Depth 4: 166 domains

TOP 20 COMMON WORDS
1. api (456 occurrences)
2. dev (234 occurrences)
3. staging (189 occurrences)
```

## Flags Reference

| Flag | Description | Example |
|------|-------------|---------|
| `-i` | Input file or `-` for stdin | `-i domains.txt` |
| `-o` | Output file or `-` for stdout | `-o clean.txt` |
| `-mode` | Operation mode | `-mode clean` |
| `-format` | Output format (txt/json/csv) | `-format json` |
| `-v` | Verbose mode | `-v` |
| `-q` | Quiet mode | `-q` |
| `-include` | Include keywords | `-include api,dev` |
| `-exclude` | Exclude keywords | `-exclude test` |
| `-tld` | Filter by TLD | `-tld com,org` |
| `-min-length` | Minimum length | `-min-length 10` |
| `-max-length` | Maximum length | `-max-length 50` |
| `-no-wildcard` | Remove wildcards | `-no-wildcard` |

## Next Steps

1. Read the full [Usage Guide](docs/usage.md)
2. Check out the [README](README.md) for detailed features
3. Run the demo script: `./demo.sh`
4. Star the repository if you find it useful!

## Tips

- Use `-v` for progress on large files
- Use `-q` for scripting (no output noise)
- Combine modes in pipelines for complex workflows
- Export analysis to JSON for programmatic processing
- Use `make test` to run all example tests

## Need Help?

```bash
./subtool -h
```

Or check the documentation in the `docs/` folder.
