#!/bin/bash

# Subdomain Toolkit - Installation Script
# Builds and installs the subtool binary

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "=================================================="
echo -e "${BLUE}  Subdomain Toolkit - Installation Script${NC}"
echo "=================================================="
echo ""

# Check for Go installation
if ! command -v go &> /dev/null; then
    echo -e "${RED}Error: Go is not installed${NC}"
    echo ""
    echo "Please install Go from https://golang.org/dl/"
    echo ""
    echo "Installation instructions:"
    echo "  1. Download Go 1.21 or later"
    echo "  2. Extract and install"
    echo "  3. Add Go to your PATH"
    echo ""
    echo "Linux/Mac:"
    echo "  wget https://go.dev/dl/go1.21.6.linux-amd64.tar.gz"
    echo "  sudo tar -C /usr/local -xzf go1.21.6.linux-amd64.tar.gz"
    echo "  export PATH=\$PATH:/usr/local/go/bin"
    echo ""
    exit 1
fi

GO_VERSION=$(go version | awk '{print $3}')
echo -e "${GREEN}✓ Go detected: $GO_VERSION${NC}"
echo ""

# Check Go version
REQUIRED_VERSION="1.21"
CURRENT_VERSION=$(go version | grep -oP 'go\K[0-9]+\.[0-9]+' | head -1)

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$CURRENT_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo -e "${YELLOW}Warning: Go version $REQUIRED_VERSION or later is recommended${NC}"
    echo -e "Current version: $CURRENT_VERSION"
    echo ""
fi

# Build options
BUILD_DIR="build"
BINARY_NAME="subtool"
INSTALL_PATH="/usr/local/bin"

echo "Build Configuration:"
echo "  Source: cmd/subtool/main.go"
echo "  Output: $BUILD_DIR/$BINARY_NAME"
echo "  Install: $INSTALL_PATH/$BINARY_NAME"
echo ""

# Ask for installation type
echo "Installation options:"
echo "  1) Build only (creates ./build/subtool)"
echo "  2) Build and install to $INSTALL_PATH (requires sudo)"
echo "  3) Build for all platforms (Linux, macOS, Windows)"
echo "  4) Run tests"
echo ""
read -p "Choose option [1-4]: " OPTION
echo ""

case $OPTION in
    1)
        echo -e "${BLUE}Building binary...${NC}"
        mkdir -p $BUILD_DIR
        go build -ldflags="-s -w" -o $BUILD_DIR/$BINARY_NAME cmd/subtool/main.go
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Build successful!${NC}"
            echo ""
            echo "Binary location: $BUILD_DIR/$BINARY_NAME"
            echo ""
            echo "To use the tool:"
            echo "  ./$BUILD_DIR/$BINARY_NAME -h"
            echo ""
            echo "To test:"
            echo "  ./$BUILD_DIR/$BINARY_NAME -mode clean -i tests/sample_inputs/test-domains.txt -o output.txt"
            echo ""
        else
            echo -e "${RED}✗ Build failed${NC}"
            exit 1
        fi
        ;;
        
    2)
        echo -e "${BLUE}Building binary...${NC}"
        mkdir -p $BUILD_DIR
        go build -ldflags="-s -w" -o $BUILD_DIR/$BINARY_NAME cmd/subtool/main.go
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Build successful!${NC}"
            echo ""
            echo -e "${BLUE}Installing to $INSTALL_PATH...${NC}"
            sudo cp $BUILD_DIR/$BINARY_NAME $INSTALL_PATH/
            
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}✓ Installation successful!${NC}"
                echo ""
                echo "The tool is now available system-wide as: $BINARY_NAME"
                echo ""
                echo "Try it:"
                echo "  $BINARY_NAME -h"
                echo "  $BINARY_NAME -mode clean -i domains.txt -o clean.txt"
                echo ""
            else
                echo -e "${RED}✗ Installation failed${NC}"
                echo "You may need to run this script with sudo"
                exit 1
            fi
        else
            echo -e "${RED}✗ Build failed${NC}"
            exit 1
        fi
        ;;
        
    3)
        echo -e "${BLUE}Building for multiple platforms...${NC}"
        mkdir -p $BUILD_DIR/release
        
        platforms=("linux/amd64" "linux/arm64" "darwin/amd64" "darwin/arm64" "windows/amd64")
        
        for platform in "${platforms[@]}"; do
            platform_split=(${platform//\// })
            GOOS=${platform_split[0]}
            GOARCH=${platform_split[1]}
            output_name=$BUILD_DIR/release/$BINARY_NAME'-'$GOOS'-'$GOARCH
            
            if [ $GOOS = "windows" ]; then
                output_name+='.exe'
            fi
            
            echo "Building for $GOOS/$GOARCH..."
            env GOOS=$GOOS GOARCH=$GOARCH go build -ldflags="-s -w" -o $output_name cmd/subtool/main.go
            
            if [ $? -ne 0 ]; then
                echo -e "${RED}✗ Build failed for $GOOS/$GOARCH${NC}"
            else
                echo -e "${GREEN}✓ Built: $output_name${NC}"
            fi
        done
        
        echo ""
        echo -e "${GREEN}✓ Multi-platform build complete!${NC}"
        echo ""
        echo "Binaries available in: $BUILD_DIR/release/"
        ls -lh $BUILD_DIR/release/
        echo ""
        ;;
        
    4)
        echo -e "${BLUE}Running tests...${NC}"
        echo ""
        
        # Build first
        mkdir -p $BUILD_DIR
        go build -ldflags="-s -w" -o $BUILD_DIR/$BINARY_NAME cmd/subtool/main.go
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}✗ Build failed${NC}"
            exit 1
        fi
        
        echo -e "${GREEN}✓ Build successful${NC}"
        echo ""
        
        # Run test suite
        echo -e "${BLUE}=== Test 1: Clean Mode ===${NC}"
        ./$BUILD_DIR/$BINARY_NAME -mode clean -i tests/sample_inputs/test-domains.txt -o $BUILD_DIR/test-clean.txt
        echo ""
        
        echo -e "${BLUE}=== Test 2: Filter Mode ===${NC}"
        ./$BUILD_DIR/$BINARY_NAME -mode filter -i tests/sample_inputs/test-domains.txt -o $BUILD_DIR/test-filter.txt -include api
        echo ""
        
        echo -e "${BLUE}=== Test 3: Analyze Mode ===${NC}"
        ./$BUILD_DIR/$BINARY_NAME -mode analyze -i tests/sample_inputs/large-test.txt -o $BUILD_DIR/test-analysis.txt
        echo ""
        
        echo -e "${BLUE}=== Test 4: JSON Output ===${NC}"
        ./$BUILD_DIR/$BINARY_NAME -mode analyze -i tests/sample_inputs/large-test.txt -format json -o $BUILD_DIR/test-analysis.json
        echo ""
        
        echo -e "${BLUE}=== Test 5: Pipeline ===${NC}"
        cat tests/sample_inputs/test-domains.txt | ./$BUILD_DIR/$BINARY_NAME -mode clean -i - -o - | ./$BUILD_DIR/$BINARY_NAME -mode filter -i - -include api -o $BUILD_DIR/test-pipeline.txt
        echo ""
        
        echo -e "${GREEN}✓ All tests completed!${NC}"
        echo ""
        echo "Test outputs in: $BUILD_DIR/"
        ls -lh $BUILD_DIR/test-*
        echo ""
        ;;
        
    *)
        echo -e "${RED}Invalid option${NC}"
        exit 1
        ;;
esac

echo ""
echo "=================================================="
echo -e "${GREEN}  Installation Complete!${NC}"
echo "=================================================="
echo ""
echo "Next steps:"
echo "  1. Read the README: less README.md"
echo "  2. Check quick start: less QUICKSTART.md"
echo "  3. Run demo script: ./demo.sh"
echo "  4. View detailed docs: less docs/usage.md"
echo ""
echo "Need help? Run: $BINARY_NAME -h"
echo ""
