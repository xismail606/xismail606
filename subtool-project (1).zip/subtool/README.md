# Subdomain Toolkit

A fast, lightweight CLI tool written in Go for cleaning, filtering, and analyzing subdomain lists. Perfect for reconnaissance, bug bounty workflows, and security testing.

## Features

### 🧹 Cleaner Mode
- Remove duplicate subdomains
- Normalize all entries to lowercase
- Remove empty lines and whitespace
- Sort output alphabetically
- Detailed statistics reporting

### 🔍 Filter Mode
- Remove wildcard entries (`*.example.com`)
- Validate domain format using regex
- Filter by keyword inclusion/exclusion
- Filter by length (min/max characters)
- TLD filtering (e.g., only `.com`, `.edu`)
- Merge multiple input files

### 📊 Analysis Mode
- Group subdomains by root domain
- Frequency analysis of repeated subdomains
- Depth analysis (e.g., `a.b.c.example.com`)
- Word extraction (identify common words like `dev`, `api`, `stage`)
- Summary reports in TXT, JSON, or CSV format

## Installation

### From Source

```bash
# Clone the repository
git clone https://github.com/yourusername/subtool.git
cd subtool

# Build the binary
go build -o subtool cmd/subtool/main.go

# Optional: Install globally
go install cmd/subtool/main.go
```

### Quick Build

```bash
cd subtool
go build -o subtool cmd/subtool/main.go
```

## Usage

### Basic Commands

```bash
# Clean and deduplicate
subtool -mode clean -i domains.txt -o clean.txt

# Filter by keywords
subtool -mode filter -i domains.txt -o filtered.txt -include api,dev

# Analyze dataset
subtool -mode analyze -i domains.txt -format json -o report.json
```

### Advanced Examples

#### Clean Large Dataset
```bash
subtool -mode clean -i large-domains.txt -o clean-domains.txt -v
```

#### Filter by Multiple Criteria
```bash
# Only .com domains containing "api" or "dev", excluding "test"
subtool -mode filter -i domains.txt -o filtered.txt \
  -include api,dev \
  -exclude test \
  -tld com \
  -min-length 10
```

#### Remove Wildcards
```bash
subtool -mode filter -i domains.txt -o no-wildcards.txt -no-wildcard
```

#### Merge Multiple Files
```bash
subtool -mode clean -merge file1.txt file2.txt file3.txt -o merged.txt
```

#### Analysis with JSON Output
```bash
subtool -mode analyze -i domains.txt -format json -o analysis.json
```

#### Pipeline Usage (stdin/stdout)
```bash
cat domains.txt | subtool -mode clean -i - -o - | subtool -mode filter -i - -include prod -o final.txt
```

### Command-Line Options

| Flag | Description | Default |
|------|-------------|---------|
| `-i <file>` | Input file (use `-` for stdin) | Required |
| `-o <file>` | Output file (use `-` for stdout) | Required |
| `-mode <mode>` | Operation mode: `clean`, `filter`, `analyze` | `clean` |
| `-format <fmt>` | Output format: `txt`, `json`, `csv` | `txt` |
| `-v` | Verbose output | `false` |
| `-q` | Quiet mode (minimal output) | `false` |
| `-no-color` | Disable colored terminal output | `false` |

### Filter Options

| Flag | Description | Example |
|------|-------------|---------|
| `-include <words>` | Include only domains with these keywords | `-include api,dev,staging` |
| `-exclude <words>` | Exclude domains with these keywords | `-exclude test,old,backup` |
| `-min-length <n>` | Minimum domain length | `-min-length 10` |
| `-max-length <n>` | Maximum domain length | `-max-length 50` |
| `-tld <list>` | Filter by TLD | `-tld com,net,org` |
| `-no-wildcard` | Remove wildcard entries | `-no-wildcard` |
| `-merge` | Merge multiple input files | `-merge` |

## Output Formats

### TXT Format (Default)
Plain text, one domain per line:
```
api.example.com
dev.example.com
staging.example.com
```

### JSON Format
Structured JSON output:
```json
{
  "total": 1234,
  "domains": [
    "api.example.com",
    "dev.example.com"
  ]
}
```

### CSV Format
CSV with headers:
```csv
subdomain
api.example.com
dev.example.com
staging.example.com
```

## Analysis Report Example

### Text Report
```
=== SUBDOMAIN ANALYSIS REPORT ===

OVERVIEW
Total Subdomains: 15,234
Unique Root Domains: 45
Max Depth Level: 5
Average Depth: 2.34

TOP 10 ROOT DOMAINS BY SUBDOMAIN COUNT
1. example.com (8,234 subdomains)
2. test.com (3,456 subdomains)
3. demo.org (2,123 subdomains)

DEPTH DISTRIBUTION
Depth 1: 234 domains
Depth 2: 8,456 domains
Depth 3: 5,234 domains
Depth 4: 1,234 domains
Depth 5: 76 domains

TOP 20 COMMON WORDS
1. api (2,345 occurrences)
2. dev (1,234 occurrences)
3. staging (987 occurrences)
```

## Performance

- **Speed**: Processes millions of domains in seconds
- **Memory**: Efficient memory usage with streaming
- **Concurrency**: Uses Go's goroutines for parallel processing
- **File Size**: Small binary (~5-10MB)

### Benchmarks

| Operation | Domains | Time | Memory |
|-----------|---------|------|--------|
| Clean | 100K | ~0.5s | ~20MB |
| Clean | 1M | ~3.5s | ~150MB |
| Filter | 100K | ~0.3s | ~15MB |
| Analyze | 100K | ~1.2s | ~30MB |

## Architecture

```
subtool/
├── cmd/subtool/          # Main entry point
├── internal/
│   ├── reader/           # File reading
│   ├── cleaner/          # Cleaning operations
│   ├── filter/           # Filtering logic
│   ├── analyzer/         # Analysis modules
│   │   ├── group.go      # Root domain grouping
│   │   ├── depth.go      # Depth analysis
│   │   └── words.go      # Word extraction
│   ├── stats/            # Statistics tracking
│   └── writer/           # Output formatting
└── tests/                # Test data
```

## Use Cases

### Bug Bounty Hunting
```bash
# Clean and analyze your subdomain enumeration results
cat amass.txt subfinder.txt assetfinder.txt | \
  subtool -mode clean -i - -o - | \
  subtool -mode filter -i - -include admin,api,dev -o targets.txt
```

### Reconnaissance
```bash
# Analyze depth distribution to find interesting subdomains
subtool -mode analyze -i all-domains.txt -format json -o analysis.json
```

### Security Testing
```bash
# Filter production domains for testing
subtool -mode filter -i domains.txt -o prod-only.txt \
  -include prod,production \
  -exclude test,dev,staging
```

## Tips & Best Practices

1. **Large Files**: Use `-v` flag to see progress on large datasets
2. **Pipelines**: Combine multiple operations using stdin/stdout
3. **Memory**: For very large files (>10M domains), process in batches
4. **Validation**: Use filter mode to validate domain formats
5. **Analysis**: Start with analysis mode to understand your dataset

## Common Issues

### Out of Memory
For extremely large files (>50M domains):
```bash
# Split and process in chunks
split -l 1000000 huge-file.txt chunk_
for file in chunk_*; do
  subtool -mode clean -i $file -o clean_$file
done
cat clean_chunk_* > final-clean.txt
```

### Slow Performance
```bash
# Use quiet mode to reduce output overhead
subtool -mode clean -i domains.txt -o clean.txt -q
```

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## License

MIT License - see LICENSE file for details

## Author

Created for security researchers and bug bounty hunters.

## Roadmap

- [ ] DNS resolution check
- [ ] HTTP/HTTPS alive check
- [ ] IP deduplication
- [ ] Config file support
- [ ] Custom regex patterns
- [ ] Export to additional formats (XML, YAML)
- [ ] Batch processing mode
- [ ] Web interface (optional)

## Support

For issues, questions, or feature requests, please open an issue on GitHub.
