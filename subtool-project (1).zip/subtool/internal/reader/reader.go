package reader

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// ReadDomains reads domains from a file or stdin
func ReadDomains(filename string) ([]string, error) {
	var scanner *bufio.Scanner

	if filename == "-" || filename == "" {
		// Read from stdin
		scanner = bufio.NewScanner(os.Stdin)
	} else {
		// Read from file
		file, err := os.Open(filename)
		if err != nil {
			return nil, fmt.Errorf("failed to open file: %w", err)
		}
		defer file.Close()
		scanner = bufio.NewScanner(file)
	}

	// Increase buffer size for large lines
	const maxCapacity = 1024 * 1024 // 1MB
	buf := make([]byte, maxCapacity)
	scanner.Buffer(buf, maxCapacity)

	var domains []string
	lineCount := 0

	for scanner.Scan() {
		lineCount++
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			domains = append(domains, line)
		}

		// Progress indicator for large files
		if lineCount%100000 == 0 {
			fmt.Fprintf(os.Stderr, "\rReading... %d lines", lineCount)
		}
	}

	if lineCount > 100000 {
		fmt.Fprintf(os.Stderr, "\r")
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error reading input: %w", err)
	}

	return domains, nil
}

// ReadMultipleFiles reads and merges multiple files
func ReadMultipleFiles(files []string, verbose bool) ([]string, error) {
	var allDomains []string

	for i, filename := range files {
		if verbose {
			fmt.Fprintf(os.Stderr, "Reading file %d/%d: %s\n", i+1, len(files), filename)
		}

		domains, err := ReadDomains(filename)
		if err != nil {
			return nil, fmt.Errorf("failed to read %s: %w", filename, err)
		}

		allDomains = append(allDomains, domains...)
	}

	return allDomains, nil
}

// ReadWithProgress reads a file with a progress callback
func ReadWithProgress(filename string, callback func(int)) ([]string, error) {
	domains, err := ReadDomains(filename)
	if err != nil {
		return nil, err
	}

	if callback != nil {
		callback(len(domains))
	}

	return domains, nil
}
