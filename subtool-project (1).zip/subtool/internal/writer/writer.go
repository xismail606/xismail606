package writer

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"subtool/internal/analyzer"
)

// Write outputs domains in the specified format
func Write(filename string, domains []string, format string) error {
	switch format {
	case "json":
		return WriteJSON(filename, domains)
	case "csv":
		return WriteCSV(filename, domains)
	case "txt":
		fallthrough
	default:
		return WriteTXT(filename, domains)
	}
}

// WriteTXT writes domains as plain text (one per line)
func WriteTXT(filename string, domains []string) error {
	var writer *os.File
	var err error

	if filename == "-" || filename == "" {
		writer = os.Stdout
	} else {
		writer, err = os.Create(filename)
		if err != nil {
			return fmt.Errorf("failed to create output file: %w", err)
		}
		defer writer.Close()
	}

	for _, domain := range domains {
		if _, err := fmt.Fprintln(writer, domain); err != nil {
			return fmt.Errorf("failed to write domain: %w", err)
		}
	}

	return nil
}

// WriteJSON writes domains as JSON array
func WriteJSON(filename string, domains []string) error {
	data := map[string]interface{}{
		"total":  len(domains),
		"domains": domains,
	}

	jsonData, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal JSON: %w", err)
	}

	if filename == "-" || filename == "" {
		fmt.Println(string(jsonData))
		return nil
	}

	if err := os.WriteFile(filename, jsonData, 0644); err != nil {
		return fmt.Errorf("failed to write JSON file: %w", err)
	}

	return nil
}

// WriteCSV writes domains as CSV
func WriteCSV(filename string, domains []string) error {
	var writer *os.File
	var err error

	if filename == "-" || filename == "" {
		writer = os.Stdout
	} else {
		writer, err = os.Create(filename)
		if err != nil {
			return fmt.Errorf("failed to create CSV file: %w", err)
		}
		defer writer.Close()
	}

	csvWriter := csv.NewWriter(writer)
	defer csvWriter.Flush()

	// Write header
	if err := csvWriter.Write([]string{"subdomain"}); err != nil {
		return fmt.Errorf("failed to write CSV header: %w", err)
	}

	// Write domains
	for _, domain := range domains {
		if err := csvWriter.Write([]string{domain}); err != nil {
			return fmt.Errorf("failed to write CSV row: %w", err)
		}
	}

	return nil
}

// WriteAnalysis writes analysis results
func WriteAnalysis(filename string, analysis *analyzer.Analysis, format string) error {
	switch format {
	case "json":
		return WriteAnalysisJSON(filename, analysis)
	case "csv":
		return WriteAnalysisCSV(filename, analysis)
	case "txt":
		fallthrough
	default:
		return WriteAnalysisTXT(filename, analysis)
	}
}

// WriteAnalysisJSON writes analysis as JSON
func WriteAnalysisJSON(filename string, analysis *analyzer.Analysis) error {
	jsonData, err := json.MarshalIndent(analysis, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal analysis JSON: %w", err)
	}

	if filename == "-" || filename == "" {
		fmt.Println(string(jsonData))
		return nil
	}

	if err := os.WriteFile(filename, jsonData, 0644); err != nil {
		return fmt.Errorf("failed to write analysis JSON: %w", err)
	}

	return nil
}

// WriteAnalysisTXT writes analysis as formatted text report
func WriteAnalysisTXT(filename string, analysis *analyzer.Analysis) error {
	var builder strings.Builder

	builder.WriteString("=== SUBDOMAIN ANALYSIS REPORT ===\n\n")
	
	// Overview
	builder.WriteString("OVERVIEW\n")
	builder.WriteString(fmt.Sprintf("Total Subdomains: %d\n", analysis.TotalSubdomains))
	builder.WriteString(fmt.Sprintf("Unique Root Domains: %d\n", len(analysis.RootDomains)))
	builder.WriteString(fmt.Sprintf("Max Depth Level: %d\n", analysis.MaxDepth))
	builder.WriteString(fmt.Sprintf("Average Depth: %.2f\n\n", analysis.AvgDepth))

	// Top root domains
	builder.WriteString("TOP 10 ROOT DOMAINS BY SUBDOMAIN COUNT\n")
	for i, group := range analysis.TopRootDomains {
		if i >= 10 {
			break
		}
		builder.WriteString(fmt.Sprintf("%d. %s (%d subdomains)\n", i+1, group.RootDomain, group.Count))
	}
	builder.WriteString("\n")

	// Depth distribution
	builder.WriteString("DEPTH DISTRIBUTION\n")
	if analysis.DepthAnalysis != nil {
		for depth := analysis.DepthAnalysis.MinDepth; depth <= analysis.DepthAnalysis.MaxDepth; depth++ {
			count := analysis.DepthAnalysis.DepthCounts[depth]
			if count > 0 {
				builder.WriteString(fmt.Sprintf("Depth %d: %d domains\n", depth, count))
			}
		}
	}
	builder.WriteString("\n")

	// Top words
	builder.WriteString("TOP 20 COMMON WORDS\n")
	for i, word := range analysis.TopWords {
		if i >= 20 {
			break
		}
		builder.WriteString(fmt.Sprintf("%d. %s (%d occurrences)\n", i+1, word.Word, word.Count))
	}
	builder.WriteString("\n")

	// Common prefixes
	if len(analysis.CommonPrefixes) > 0 {
		builder.WriteString("COMMON PREFIXES (appearing 5+ times)\n")
		count := 0
		for prefix, freq := range analysis.CommonPrefixes {
			if count >= 20 {
				break
			}
			builder.WriteString(fmt.Sprintf("  %s: %d\n", prefix, freq))
			count++
		}
		builder.WriteString("\n")
	}

	report := builder.String()

	if filename == "-" || filename == "" {
		fmt.Print(report)
		return nil
	}

	if err := os.WriteFile(filename, []byte(report), 0644); err != nil {
		return fmt.Errorf("failed to write analysis report: %w", err)
	}

	return nil
}

// WriteAnalysisCSV writes analysis as CSV
func WriteAnalysisCSV(filename string, analysis *analyzer.Analysis) error {
	var writer *os.File
	var err error

	if filename == "-" || filename == "" {
		writer = os.Stdout
	} else {
		writer, err = os.Create(filename)
		if err != nil {
			return fmt.Errorf("failed to create CSV file: %w", err)
		}
		defer writer.Close()
	}

	csvWriter := csv.NewWriter(writer)
	defer csvWriter.Flush()

	// Write root domain statistics
	csvWriter.Write([]string{"Root Domain", "Subdomain Count"})
	for _, group := range analysis.TopRootDomains {
		csvWriter.Write([]string{group.RootDomain, fmt.Sprintf("%d", group.Count)})
	}

	return nil
}
