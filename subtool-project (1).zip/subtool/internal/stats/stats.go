package stats

import (
	"time"
)

// Stats holds processing statistics
type Stats struct {
	TotalLines        int
	UniqueSubdomains  int
	DuplicatesRemoved int
	InvalidEntries    int
	Duration          time.Duration
}

// NewStats creates a new statistics tracker
func NewStats() *Stats {
	return &Stats{}
}

// Update updates statistics
func (s *Stats) Update(unique, duplicates, invalid int) {
	s.UniqueSubdomains = unique
	s.DuplicatesRemoved = duplicates
	s.InvalidEntries = invalid
}

// AddInvalid increments invalid entry count
func (s *Stats) AddInvalid() {
	s.InvalidEntries++
}

// AddDuplicate increments duplicate count
func (s *Stats) AddDuplicate() {
	s.DuplicatesRemoved++
}

// SetTotalLines sets total lines read
func (s *Stats) SetTotalLines(total int) {
	s.TotalLines = total
}
