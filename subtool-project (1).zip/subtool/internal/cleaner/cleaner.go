package cleaner

import (
	"fmt"
	"os"
	"sort"
	"strings"

	"subtool/internal/stats"
)

// Clean performs cleaning operations on domains
func Clean(domains []string, statistics *stats.Stats, verbose bool) []string {
	if verbose {
		fmt.Fprintf(os.Stderr, "Starting cleaning process...\n")
	}

	// Use map for deduplication
	uniqueMap := make(map[string]bool)
	var cleaned []string

	processed := 0
	duplicates := 0

	for _, domain := range domains {
		processed++

		// Normalize: trim and lowercase
		normalized := strings.ToLower(strings.TrimSpace(domain))

		// Skip empty entries
		if normalized == "" {
			statistics.InvalidEntries++
			continue
		}

		// Check for duplicates
		if uniqueMap[normalized] {
			duplicates++
			continue
		}

		// Add to unique set
		uniqueMap[normalized] = true
		cleaned = append(cleaned, normalized)

		// Progress for large datasets
		if verbose && processed%100000 == 0 {
			fmt.Fprintf(os.Stderr, "Processed %d domains...\n", processed)
		}
	}

	// Sort alphabetically
	if verbose {
		fmt.Fprintf(os.Stderr, "Sorting %d unique domains...\n", len(cleaned))
	}
	sort.Strings(cleaned)

	// Update statistics
	statistics.UniqueSubdomains = len(cleaned)
	statistics.DuplicatesRemoved = duplicates

	return cleaned
}

// Normalize performs normalization without deduplication
func Normalize(domains []string) []string {
	normalized := make([]string, 0, len(domains))

	for _, domain := range domains {
		clean := strings.ToLower(strings.TrimSpace(domain))
		if clean != "" {
			normalized = append(normalized, clean)
		}
	}

	return normalized
}

// Deduplicate removes duplicates while preserving order
func Deduplicate(domains []string) []string {
	seen := make(map[string]bool)
	unique := make([]string, 0, len(domains))

	for _, domain := range domains {
		if !seen[domain] {
			seen[domain] = true
			unique = append(unique, domain)
		}
	}

	return unique
}

// RemoveEmpty removes empty lines and whitespace
func RemoveEmpty(domains []string) []string {
	cleaned := make([]string, 0, len(domains))

	for _, domain := range domains {
		trimmed := strings.TrimSpace(domain)
		if trimmed != "" {
			cleaned = append(cleaned, trimmed)
		}
	}

	return cleaned
}
