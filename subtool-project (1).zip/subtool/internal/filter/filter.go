package filter

import (
	"fmt"
	"os"
	"regexp"
	"strings"

	"subtool/internal/stats"
)

// Config holds filter configuration
type Config struct {
	IncludeWords   []string
	ExcludeWords   []string
	MinLength      int
	MaxLength      int
	TLDs           []string
	RemoveWildcard bool
}

// Domain validation regex
var domainRegex = regexp.MustCompile(`^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$`)
var wildcardRegex = regexp.MustCompile(`^\*\.`)

// Apply applies all configured filters
func Apply(domains []string, config *Config, statistics *stats.Stats, verbose bool) []string {
	if verbose {
		fmt.Fprintf(os.Stderr, "Applying filters...\n")
	}

	var filtered []string
	processed := 0

	for _, domain := range domains {
		processed++

		// Normalize
		domain = strings.ToLower(strings.TrimSpace(domain))

		// Skip empty
		if domain == "" {
			statistics.InvalidEntries++
			continue
		}

		// Apply all filters
		if !passesFilters(domain, config) {
			continue
		}

		filtered = append(filtered, domain)

		// Progress
		if verbose && processed%100000 == 0 {
			fmt.Fprintf(os.Stderr, "Filtered %d/%d domains...\n", len(filtered), processed)
		}
	}

	statistics.UniqueSubdomains = len(filtered)
	return filtered
}

// passesFilters checks if a domain passes all filter criteria
func passesFilters(domain string, config *Config) bool {
	// Wildcard filter
	if config.RemoveWildcard && wildcardRegex.MatchString(domain) {
		return false
	}

	// Validate domain format
	if !IsValidDomain(domain) {
		return false
	}

	// Length filters
	if config.MinLength > 0 && len(domain) < config.MinLength {
		return false
	}
	if config.MaxLength > 0 && len(domain) > config.MaxLength {
		return false
	}

	// Include words filter
	if len(config.IncludeWords) > 0 {
		if !containsAny(domain, config.IncludeWords) {
			return false
		}
	}

	// Exclude words filter
	if len(config.ExcludeWords) > 0 {
		if containsAny(domain, config.ExcludeWords) {
			return false
		}
	}

	// TLD filter
	if len(config.TLDs) > 0 {
		if !hasTLD(domain, config.TLDs) {
			return false
		}
	}

	return true
}

// IsValidDomain checks if a string is a valid domain
func IsValidDomain(domain string) bool {
	// Skip wildcard check for validation
	domain = strings.TrimPrefix(domain, "*.")
	
	// Basic validation
	if len(domain) == 0 || len(domain) > 253 {
		return false
	}

	// Check format with regex
	return domainRegex.MatchString(domain)
}

// containsAny checks if domain contains any of the keywords
func containsAny(domain string, keywords []string) bool {
	for _, keyword := range keywords {
		if keyword != "" && strings.Contains(domain, strings.ToLower(keyword)) {
			return true
		}
	}
	return false
}

// hasTLD checks if domain has one of the specified TLDs
func hasTLD(domain string, tlds []string) bool {
	for _, tld := range tlds {
		if tld != "" && strings.HasSuffix(domain, "."+strings.ToLower(tld)) {
			return true
		}
	}
	return false
}

// FilterByRegex filters domains using a custom regex pattern
func FilterByRegex(domains []string, pattern string) ([]string, error) {
	regex, err := regexp.Compile(pattern)
	if err != nil {
		return nil, fmt.Errorf("invalid regex pattern: %w", err)
	}

	var filtered []string
	for _, domain := range domains {
		if regex.MatchString(domain) {
			filtered = append(filtered, domain)
		}
	}

	return filtered, nil
}

// RemoveWildcards removes all wildcard entries
func RemoveWildcards(domains []string) []string {
	var filtered []string
	for _, domain := range domains {
		if !wildcardRegex.MatchString(domain) {
			filtered = append(filtered, domain)
		}
	}
	return filtered
}

// FilterByLength filters by minimum and maximum length
func FilterByLength(domains []string, min, max int) []string {
	var filtered []string
	for _, domain := range domains {
		length := len(domain)
		if (min == 0 || length >= min) && (max == 0 || length <= max) {
			filtered = append(filtered, domain)
		}
	}
	return filtered
}
