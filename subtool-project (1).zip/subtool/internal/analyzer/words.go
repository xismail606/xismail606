package analyzer

import (
	"regexp"
	"strings"
)

// WordCount represents a word and its frequency
type WordCount struct {
	Word  string `json:"word"`
	Count int    `json:"count"`
}

// Common words to exclude from analysis
var stopWords = map[string]bool{
	"com": true, "net": true, "org": true, "edu": true, "gov": true,
	"co": true, "uk": true, "us": true, "de": true, "fr": true,
	"www": true, "mail": true, "ftp": true, "http": true, "https": true,
}

// Word extraction regex - splits on dots and hyphens
var wordSplitRegex = regexp.MustCompile(`[.\-]+`)

// ExtractWords extracts and counts words from subdomains
func ExtractWords(domains []string) map[string]int {
	wordCounts := make(map[string]int)

	for _, domain := range domains {
		words := extractWordsFromDomain(domain)
		for _, word := range words {
			if shouldCountWord(word) {
				wordCounts[word]++
			}
		}
	}

	return wordCounts
}

// extractWordsFromDomain splits a domain into individual words
func extractWordsFromDomain(domain string) []string {
	// Remove wildcard
	domain = strings.TrimPrefix(domain, "*.")
	
	// Convert to lowercase
	domain = strings.ToLower(domain)
	
	// Split by dots and hyphens
	parts := wordSplitRegex.Split(domain, -1)
	
	var words []string
	for _, part := range parts {
		if part != "" {
			words = append(words, part)
		}
	}
	
	return words
}

// shouldCountWord determines if a word should be counted
func shouldCountWord(word string) bool {
	// Skip very short words
	if len(word) < 2 {
		return false
	}
	
	// Skip stop words
	if stopWords[word] {
		return false
	}
	
	// Skip pure numbers
	if isNumeric(word) {
		return false
	}
	
	return true
}

// isNumeric checks if a string is purely numeric
func isNumeric(s string) bool {
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

// GetTopWords returns the top N most common words
func GetTopWords(wordCounts map[string]int, n int) []WordCount {
	// Convert map to slice
	var words []WordCount
	for word, count := range wordCounts {
		words = append(words, WordCount{Word: word, Count: count})
	}

	// Sort by count (descending) - bubble sort for simplicity
	for i := 0; i < len(words)-1; i++ {
		for j := i + 1; j < len(words); j++ {
			if words[j].Count > words[i].Count {
				words[i], words[j] = words[j], words[i]
			}
		}
	}

	// Return top N
	if n > len(words) {
		n = len(words)
	}
	return words[:n]
}

// FindCommonPrefixes finds common prefixes in domains
func FindCommonPrefixes(domains []string, minCount int) map[string]int {
	prefixes := make(map[string]int)

	for _, domain := range domains {
		parts := strings.Split(domain, ".")
		if len(parts) > 0 {
			prefix := parts[0]
			prefixes[prefix]++
		}
	}

	// Filter by minimum count
	filtered := make(map[string]int)
	for prefix, count := range prefixes {
		if count >= minCount {
			filtered[prefix] = count
		}
	}

	return filtered
}

// FindCommonSuffixes finds common suffixes in domains
func FindCommonSuffixes(domains []string, minCount int) map[string]int {
	suffixes := make(map[string]int)

	for _, domain := range domains {
		parts := strings.Split(domain, ".")
		if len(parts) >= 2 {
			suffix := parts[len(parts)-2] + "." + parts[len(parts)-1]
			suffixes[suffix]++
		}
	}

	// Filter by minimum count
	filtered := make(map[string]int)
	for suffix, count := range suffixes {
		if count >= minCount {
			filtered[suffix] = count
		}
	}

	return filtered
}
