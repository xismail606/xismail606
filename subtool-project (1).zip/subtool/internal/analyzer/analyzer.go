package analyzer

import (
	"fmt"
	"os"
)

// Analysis holds complete analysis results
type Analysis struct {
	TotalSubdomains int                         `json:"total_subdomains"`
	RootDomains     map[string]*RootDomainGroup `json:"root_domains"`
	TopRootDomains  []*RootDomainGroup          `json:"top_root_domains"`
	DepthAnalysis   *DepthAnalysis              `json:"depth_analysis"`
	MaxDepth        int                         `json:"max_depth"`
	AvgDepth        float64                     `json:"avg_depth"`
	WordCounts      map[string]int              `json:"word_counts"`
	TopWords        []WordCount                 `json:"top_words"`
	CommonPrefixes  map[string]int              `json:"common_prefixes"`
	CommonSuffixes  map[string]int              `json:"common_suffixes"`
}

// Analyze performs comprehensive analysis on domains
func Analyze(domains []string, verbose bool) *Analysis {
	analysis := &Analysis{
		TotalSubdomains: len(domains),
	}

	// Group by root domain
	if verbose {
		fmt.Fprintf(os.Stderr, "Grouping by root domain...\n")
	}
	analysis.RootDomains = GroupByRootDomain(domains)
	analysis.TopRootDomains = GetTopRootDomains(analysis.RootDomains, 20)

	// Depth analysis
	if verbose {
		fmt.Fprintf(os.Stderr, "Analyzing depth levels...\n")
	}
	depthAnalysis := AnalyzeDepth(domains)
	analysis.DepthAnalysis = depthAnalysis
	analysis.MaxDepth = depthAnalysis.MaxDepth
	analysis.AvgDepth = depthAnalysis.AvgDepth

	// Word extraction
	if verbose {
		fmt.Fprintf(os.Stderr, "Extracting common words...\n")
	}
	analysis.WordCounts = ExtractWords(domains)
	analysis.TopWords = GetTopWords(analysis.WordCounts, 50)

	// Common prefixes and suffixes
	if verbose {
		fmt.Fprintf(os.Stderr, "Finding common patterns...\n")
	}
	analysis.CommonPrefixes = FindCommonPrefixes(domains, 5)
	analysis.CommonSuffixes = FindCommonSuffixes(domains, 5)

	return analysis
}

// QuickAnalyze performs a lighter analysis (useful for very large datasets)
func QuickAnalyze(domains []string) *Analysis {
	analysis := &Analysis{
		TotalSubdomains: len(domains),
	}

	// Basic grouping
	analysis.RootDomains = GroupByRootDomain(domains)
	analysis.TopRootDomains = GetTopRootDomains(analysis.RootDomains, 10)

	// Basic depth
	depthAnalysis := AnalyzeDepth(domains)
	analysis.MaxDepth = depthAnalysis.MaxDepth
	analysis.AvgDepth = depthAnalysis.AvgDepth

	return analysis
}

// AnalyzeByRootDomain analyzes a specific root domain
func AnalyzeByRootDomain(domains []string, rootDomain string) *Analysis {
	// Filter domains for this root
	var filtered []string
	for _, domain := range domains {
		if extractRootDomain(domain) == rootDomain {
			filtered = append(filtered, domain)
		}
	}

	return Analyze(filtered, false)
}

// CompareAnalysis compares two domain lists
type ComparisonResult struct {
	OnlyInFirst  []string `json:"only_in_first"`
	OnlyInSecond []string `json:"only_in_second"`
	Common       []string `json:"common"`
}

// Compare compares two domain lists
func Compare(first, second []string) *ComparisonResult {
	firstSet := make(map[string]bool)
	secondSet := make(map[string]bool)

	for _, d := range first {
		firstSet[d] = true
	}
	for _, d := range second {
		secondSet[d] = true
	}

	result := &ComparisonResult{}

	for d := range firstSet {
		if secondSet[d] {
			result.Common = append(result.Common, d)
		} else {
			result.OnlyInFirst = append(result.OnlyInFirst, d)
		}
	}

	for d := range secondSet {
		if !firstSet[d] {
			result.OnlyInSecond = append(result.OnlyInSecond, d)
		}
	}

	return result
}
