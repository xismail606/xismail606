package analyzer

import (
	"strings"
)

// RootDomainGroup represents subdomains grouped by root domain
type RootDomainGroup struct {
	RootDomain string   `json:"root_domain"`
	Subdomains []string `json:"subdomains"`
	Count      int      `json:"count"`
}

// GroupByRootDomain groups subdomains by their root domain
func GroupByRootDomain(domains []string) map[string]*RootDomainGroup {
	groups := make(map[string]*RootDomainGroup)

	for _, domain := range domains {
		root := extractRootDomain(domain)
		if root == "" {
			continue
		}

		if _, exists := groups[root]; !exists {
			groups[root] = &RootDomainGroup{
				RootDomain: root,
				Subdomains: []string{},
				Count:      0,
			}
		}

		groups[root].Subdomains = append(groups[root].Subdomains, domain)
		groups[root].Count++
	}

	return groups
}

// extractRootDomain extracts the root domain from a subdomain
func extractRootDomain(domain string) string {
	// Remove wildcard prefix
	domain = strings.TrimPrefix(domain, "*.")

	parts := strings.Split(domain, ".")
	if len(parts) < 2 {
		return ""
	}

	// Return last two parts (domain.tld)
	return strings.Join(parts[len(parts)-2:], ".")
}

// GetTopRootDomains returns the top N root domains by subdomain count
func GetTopRootDomains(groups map[string]*RootDomainGroup, n int) []*RootDomainGroup {
	// Convert map to slice
	var list []*RootDomainGroup
	for _, group := range groups {
		list = append(list, group)
	}

	// Sort by count (descending)
	for i := 0; i < len(list)-1; i++ {
		for j := i + 1; j < len(list); j++ {
			if list[j].Count > list[i].Count {
				list[i], list[j] = list[j], list[i]
			}
		}
	}

	// Return top N
	if n > len(list) {
		n = len(list)
	}
	return list[:n]
}

// CountByRootDomain returns count of subdomains per root domain
func CountByRootDomain(domains []string) map[string]int {
	counts := make(map[string]int)

	for _, domain := range domains {
		root := extractRootDomain(domain)
		if root != "" {
			counts[root]++
		}
	}

	return counts
}
