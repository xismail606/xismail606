package analyzer

import (
	"strings"
)

// DepthAnalysis contains depth statistics
type DepthAnalysis struct {
	MaxDepth      int            `json:"max_depth"`
	MinDepth      int            `json:"min_depth"`
	AvgDepth      float64        `json:"avg_depth"`
	DepthCounts   map[int]int    `json:"depth_counts"`
	ByDepthLevel  map[int][]string `json:"by_depth_level"`
}

// AnalyzeDepth analyzes subdomain depth levels
func AnalyzeDepth(domains []string) *DepthAnalysis {
	analysis := &DepthAnalysis{
		MaxDepth:     0,
		MinDepth:     999,
		DepthCounts:  make(map[int]int),
		ByDepthLevel: make(map[int][]string),
	}

	if len(domains) == 0 {
		return analysis
	}

	totalDepth := 0

	for _, domain := range domains {
		depth := calculateDepth(domain)
		
		// Update min/max
		if depth > analysis.MaxDepth {
			analysis.MaxDepth = depth
		}
		if depth < analysis.MinDepth {
			analysis.MinDepth = depth
		}

		// Count by depth
		analysis.DepthCounts[depth]++
		
		// Group by depth
		analysis.ByDepthLevel[depth] = append(analysis.ByDepthLevel[depth], domain)
		
		totalDepth += depth
	}

	// Calculate average
	analysis.AvgDepth = float64(totalDepth) / float64(len(domains))

	return analysis
}

// calculateDepth calculates the depth of a subdomain
func calculateDepth(domain string) int {
	// Remove wildcard prefix
	domain = strings.TrimPrefix(domain, "*.")
	
	// Count dots
	return strings.Count(domain, ".")
}

// GetDomainsByDepth returns all domains at a specific depth level
func GetDomainsByDepth(domains []string, depth int) []string {
	var result []string
	
	for _, domain := range domains {
		if calculateDepth(domain) == depth {
			result = append(result, domain)
		}
	}
	
	return result
}

// FilterByDepth filters domains by depth range
func FilterByDepth(domains []string, minDepth, maxDepth int) []string {
	var result []string
	
	for _, domain := range domains {
		depth := calculateDepth(domain)
		if depth >= minDepth && depth <= maxDepth {
			result = append(result, domain)
		}
	}
	
	return result
}
