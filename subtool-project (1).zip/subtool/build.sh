#!/bin/bash

# Subdomain Toolkit - Build Verification Script
# Use this on your local machine

echo "=========================================="
echo "  Subdomain Toolkit - Build Script"
echo "=========================================="
echo ""

# Check Go installation
echo "Checking Go installation..."
if ! command -v go &> /dev/null; then
    echo "❌ Go is not installed!"
    exit 1
fi

GO_VERSION=$(go version)
echo "✓ $GO_VERSION"
echo ""

# Build the project
echo "Building subtool..."
cd "$(dirname "$0")"

go build -ldflags="-s -w" -o subtool cmd/subtool/main.go

if [ $? -eq 0 ]; then
    echo ""
    echo "✓ Build successful!"
    echo ""
    echo "Binary created: ./subtool"
    echo "Size: $(du -h subtool | cut -f1)"
    echo ""
    echo "Try it:"
    echo "  ./subtool -h"
    echo "  ./subtool -mode clean -i tests/sample_inputs/test-domains.txt -o output.txt"
    echo ""
else
    echo ""
    echo "❌ Build failed!"
    exit 1
fi
