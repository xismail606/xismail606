#!/bin/bash

# Subdomain Toolkit - Demo and Test Script
# This script demonstrates all features of the tool

set -e

echo "=================================================="
echo "  Subdomain Toolkit - Demo Script"
echo "=================================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if binary exists
BINARY="./build/subtool"
if [ ! -f "$BINARY" ]; then
    echo -e "${YELLOW}Binary not found. Building...${NC}"
    make build
    echo ""
fi

# Create output directory
mkdir -p ./demo-output

echo -e "${BLUE}=== Demo 1: Clean Mode ===${NC}"
echo "Command: subtool -mode clean -i tests/sample_inputs/test-domains.txt -o demo-output/clean.txt"
echo ""
$BINARY -mode clean -i tests/sample_inputs/test-domains.txt -o demo-output/clean.txt -v
echo ""
echo -e "${GREEN}✓ Clean output saved to: demo-output/clean.txt${NC}"
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 2: Filter Mode - Include Keywords ===${NC}"
echo "Command: subtool -mode filter -i tests/sample_inputs/test-domains.txt -o demo-output/api-only.txt -include api"
echo ""
$BINARY -mode filter -i tests/sample_inputs/test-domains.txt -o demo-output/api-only.txt -include api -v
echo ""
echo -e "${GREEN}✓ Filtered output (API only) saved to: demo-output/api-only.txt${NC}"
cat demo-output/api-only.txt
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 3: Filter Mode - Remove Wildcards ===${NC}"
echo "Command: subtool -mode filter -i tests/sample_inputs/test-domains.txt -o demo-output/no-wildcards.txt -no-wildcard"
echo ""
$BINARY -mode filter -i tests/sample_inputs/test-domains.txt -o demo-output/no-wildcards.txt -no-wildcard -v
echo ""
echo -e "${GREEN}✓ Non-wildcard domains saved to: demo-output/no-wildcards.txt${NC}"
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 4: Filter Mode - Multiple Criteria ===${NC}"
echo "Command: subtool -mode filter -include api,dev -exclude test -tld com"
echo ""
$BINARY -mode filter -i tests/sample_inputs/test-domains.txt -o demo-output/complex-filter.txt \
    -include api,dev \
    -exclude test \
    -tld com \
    -v
echo ""
echo -e "${GREEN}✓ Complex filtered output saved to: demo-output/complex-filter.txt${NC}"
cat demo-output/complex-filter.txt
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 5: Analyze Mode - Text Report ===${NC}"
echo "Command: subtool -mode analyze -i tests/sample_inputs/test-domains.txt -o demo-output/analysis.txt"
echo ""
$BINARY -mode analyze -i tests/sample_inputs/test-domains.txt -o demo-output/analysis.txt -v
echo ""
echo -e "${GREEN}✓ Analysis report saved to: demo-output/analysis.txt${NC}"
echo ""
echo "--- Analysis Report Preview ---"
head -30 demo-output/analysis.txt
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 6: Analyze Mode - JSON Output ===${NC}"
echo "Command: subtool -mode analyze -i tests/sample_inputs/test-domains.txt -format json -o demo-output/analysis.json"
echo ""
$BINARY -mode analyze -i tests/sample_inputs/test-domains.txt -format json -o demo-output/analysis.json -v
echo ""
echo -e "${GREEN}✓ JSON analysis saved to: demo-output/analysis.json${NC}"
echo ""
echo "--- JSON Preview ---"
head -40 demo-output/analysis.json
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 7: Pipeline Usage ===${NC}"
echo "Command: cat input | clean | filter | output"
echo ""
cat tests/sample_inputs/test-domains.txt | \
    $BINARY -mode clean -i - -o - | \
    $BINARY -mode filter -i - -include api -o demo-output/pipeline.txt
echo ""
echo -e "${GREEN}✓ Pipeline output saved to: demo-output/pipeline.txt${NC}"
cat demo-output/pipeline.txt
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 8: CSV Output ===${NC}"
echo "Command: subtool -mode analyze -format csv"
echo ""
$BINARY -mode analyze -i tests/sample_inputs/test-domains.txt -format csv -o demo-output/analysis.csv
echo ""
echo -e "${GREEN}✓ CSV analysis saved to: demo-output/analysis.csv${NC}"
echo ""
echo "--- CSV Preview ---"
head -20 demo-output/analysis.csv
echo ""
read -p "Press Enter to continue..."
echo ""

echo -e "${BLUE}=== Demo 9: Quiet Mode (No Statistics) ===${NC}"
echo "Command: subtool -mode clean -q"
echo ""
$BINARY -mode clean -i tests/sample_inputs/test-domains.txt -o demo-output/quiet.txt -q
echo ""
echo -e "${GREEN}✓ Quiet mode output saved (no stats displayed)${NC}"
echo ""

echo ""
echo "=================================================="
echo -e "${GREEN}  All demos completed successfully!${NC}"
echo "=================================================="
echo ""
echo "Output files created in ./demo-output/:"
ls -lh demo-output/
echo ""
echo -e "${YELLOW}Tips:${NC}"
echo "  - Try different filter combinations"
echo "  - Use -v for verbose output"
echo "  - Analyze JSON output with jq"
echo "  - Chain commands in pipelines"
echo ""
echo "For more information, see docs/usage.md"
echo ""
