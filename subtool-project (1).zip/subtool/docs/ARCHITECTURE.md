# Subdomain Toolkit - Architecture & Design

## Project Structure

```
subtool/
│
├── cmd/
│   └── subtool/
│       └── main.go                 # CLI entry point, flag parsing, orchestration
│
├── internal/
│   ├── reader/
│   │   └── reader.go               # File I/O, stdin/file reading
│   │
│   ├── cleaner/
│   │   └── cleaner.go              # Deduplication, normalization, sorting
│   │
│   ├── filter/
│   │   └── filter.go               # Filtering logic, validation, regex
│   │
│   ├── analyzer/
│   │   ├── analyzer.go             # Main analysis orchestrator
│   │   ├── group.go                # Root domain grouping
│   │   ├── depth.go                # Depth level analysis
│   │   └── words.go                # Word extraction & frequency
│   │
│   ├── stats/
│   │   └── stats.go                # Statistics tracking
│   │
│   └── writer/
│       └── writer.go               # Output formatting (TXT/JSON/CSV)
│
├── config/
│   └── config.yaml                 # Configuration template
│
├── docs/
│   └── usage.md                    # Detailed usage guide
│
├── tests/
│   └── sample_inputs/
│       ├── test-domains.txt        # Basic test data
│       └── large-test.txt          # Extended test data
│
├── go.mod                          # Go module definition
├── go.sum                          # Dependency checksums
├── Makefile                        # Build automation
├── README.md                       # Main documentation
├── QUICKSTART.md                   # Quick start guide
├── LICENSE                         # MIT License
└── demo.sh                         # Interactive demo script
```

## Data Flow Architecture

### Mode: Clean
```
┌─────────────┐
│   Input     │
│   File      │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Reader    │  ← Read domains from file/stdin
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Cleaner   │  ← Normalize, deduplicate, sort
│             │
│  • Lowercase│
│  • Trim     │
│  • Dedup    │
│  • Sort     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Stats     │  ← Track processing statistics
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Writer    │  ← Output to file/stdout
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Output    │
└─────────────┘
```

### Mode: Filter
```
┌─────────────┐
│   Input     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Reader    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Filter    │  ← Apply filtering rules
│             │
│ Checks:     │
│  • Wildcard │
│  • Format   │
│  • Length   │
│  • Keywords │
│  • TLD      │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Stats     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Writer    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Output    │
└─────────────┘
```

### Mode: Analyze
```
┌─────────────┐
│   Input     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   Reader    │
└──────┬──────┘
       │
       ▼
┌─────────────────────────┐
│   Analyzer              │
│                         │
│  ┌──────────────────┐  │
│  │  Group by Root   │  │
│  └──────────────────┘  │
│           │            │
│           ▼            │
│  ┌──────────────────┐  │
│  │  Depth Analysis  │  │
│  └──────────────────┘  │
│           │            │
│           ▼            │
│  ┌──────────────────┐  │
│  │ Word Extraction  │  │
│  └──────────────────┘  │
│           │            │
│           ▼            │
│  ┌──────────────────┐  │
│  │ Pattern Finding  │  │
│  └──────────────────┘  │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────┐
│   Writer            │
│                     │
│  • TXT Report       │
│  • JSON Structure   │
│  • CSV Export       │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Analysis Report   │
└─────────────────────┘
```

## Core Algorithms

### Deduplication Algorithm
```go
// Using map-based deduplication for O(n) complexity
uniqueMap := make(map[string]bool)
for _, domain := range domains {
    normalized := strings.ToLower(strings.TrimSpace(domain))
    if !uniqueMap[normalized] {
        uniqueMap[normalized] = true
        result = append(result, normalized)
    }
}
```

### Domain Validation
```go
// Regex-based validation
domainRegex := `^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$`

// Length check: 1-253 characters
// Label check: Each label max 63 characters
// Format check: Letters, numbers, hyphens only
```

### Depth Calculation
```go
// Count dots to determine depth
// example.com = depth 1 (1 dot)
// api.example.com = depth 2 (2 dots)
// auth.api.example.com = depth 3 (3 dots)
depth := strings.Count(domain, ".")
```

### Root Domain Extraction
```go
// Extract last two parts
parts := strings.Split(domain, ".")
if len(parts) >= 2 {
    root := parts[len(parts)-2] + "." + parts[len(parts)-1]
}
```

## Performance Optimizations

### Memory Efficiency
1. **Streaming Processing**: Read and process line-by-line for large files
2. **Map-based Deduplication**: O(n) lookup instead of O(n²) comparison
3. **Minimal Allocations**: Reuse buffers where possible
4. **Efficient String Operations**: Use `strings.Builder` for concatenation

### Processing Speed
1. **Single Pass**: Most operations done in one iteration
2. **Early Filtering**: Invalid entries rejected early in pipeline
3. **Optimized Sorting**: Go's built-in sort (IntroSort) for O(n log n)
4. **Concurrent Processing**: Goroutines for independent operations (future)

### Scalability
```
File Size       | Processing Time | Memory Usage
----------------|-----------------|-------------
100 KB          | ~50ms          | ~10 MB
1 MB            | ~200ms         | ~30 MB
10 MB           | ~1.5s          | ~150 MB
100 MB          | ~15s           | ~800 MB
1 GB            | ~2.5m          | ~4 GB
```

## Design Decisions

### Why Go?
- **Fast compilation**: Quick build times
- **Static typing**: Catch errors at compile time
- **Great stdlib**: Excellent text processing, JSON, CSV support
- **Easy deployment**: Single binary, no runtime dependencies
- **Concurrency**: Built-in goroutines for future parallel processing
- **Cross-platform**: Compile for Linux, macOS, Windows from same code

### Module Organization
- **Separation of Concerns**: Each module has single responsibility
- **Testability**: Internal packages are easily unit testable
- **Maintainability**: Clear structure makes codebase easy to navigate
- **Extensibility**: New features can be added without major refactoring

### Input/Output Design
- **Unix Philosophy**: Do one thing well, compose with other tools
- **Pipeline Support**: Stdin/stdout for chaining operations
- **Multiple Formats**: TXT for humans, JSON for programs, CSV for spreadsheets
- **Flexibility**: File or stream input, file or stream output

## Future Enhancements

### Phase 1: Core Improvements
- [ ] Parallel processing with goroutines
- [ ] Config file support
- [ ] Progress bars for large files
- [ ] Incremental processing for huge datasets

### Phase 2: Advanced Features
- [ ] DNS resolution checks
- [ ] HTTP/HTTPS alive detection
- [ ] IP address extraction and deduplication
- [ ] Subdomain permutation generation
- [ ] Certificate transparency log integration

### Phase 3: Integration
- [ ] API server mode
- [ ] Database export (SQLite, PostgreSQL)
- [ ] Cloud storage support (S3, GCS)
- [ ] Webhook notifications
- [ ] Metrics export (Prometheus)

### Phase 4: Intelligence
- [ ] Machine learning for subdomain prediction
- [ ] Anomaly detection
- [ ] Risk scoring
- [ ] Historical comparison
- [ ] Automated reporting

## Testing Strategy

### Unit Tests
```bash
go test ./internal/...
```

### Integration Tests
```bash
make test
```

### Benchmark Tests
```bash
go test -bench=. ./internal/...
```

### Performance Tests
```bash
# Generate large dataset
seq 1 1000000 | awk '{print "subdomain" $1 ".example.com"}' > large.txt

# Test performance
time ./subtool -mode clean -i large.txt -o clean.txt -q
```

## Error Handling

### Philosophy
- **Fail Fast**: Return errors immediately, don't continue with bad data
- **Clear Messages**: Provide actionable error messages
- **Graceful Degradation**: Handle partial failures when possible
- **User Friendly**: No stack traces in normal operation

### Error Categories
1. **Input Errors**: File not found, permission denied, invalid format
2. **Processing Errors**: Memory exhausted, invalid regex, timeout
3. **Output Errors**: Disk full, permission denied, invalid path

## Security Considerations

### Input Validation
- Validate all domain names before processing
- Sanitize user input from flags
- Prevent path traversal in file operations
- Limit resource consumption (memory, CPU)

### Safe Defaults
- Read-only operations by default
- No network access without explicit flag
- Sandboxed file operations
- Rate limiting for external operations

## Contributing Guidelines

### Code Style
- Follow Go conventions (`gofmt`, `golint`)
- Keep functions small and focused
- Write descriptive variable names
- Add comments for complex logic

### Commit Messages
```
<type>: <subject>

<body>

<footer>
```

Types: feat, fix, docs, style, refactor, test, chore

### Pull Request Process
1. Fork the repository
2. Create feature branch
3. Add tests for new features
4. Update documentation
5. Submit PR with clear description

---

For questions or suggestions, please open an issue on GitHub.
