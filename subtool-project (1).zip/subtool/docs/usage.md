# Subdomain Toolkit - Detailed Usage Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Mode: Clean](#mode-clean)
3. [Mode: Filter](#mode-filter)
4. [Mode: Analyze](#mode-analyze)
5. [Advanced Workflows](#advanced-workflows)
6. [Performance Tuning](#performance-tuning)

## Getting Started

### Installation

```bash
# Build from source
cd subtool
go build -o subtool cmd/subtool/main.go

# Make executable
chmod +x subtool

# Optional: Move to PATH
sudo mv subtool /usr/local/bin/
```

### Basic Syntax

```bash
subtool -mode <mode> -i <input> -o <output> [options]
```

## Mode: Clean

The clean mode removes duplicates, normalizes formatting, and sorts subdomains.

### What It Does
1. Converts all domains to lowercase
2. Removes leading/trailing whitespace
3. Removes duplicate entries
4. Removes empty lines
5. Sorts alphabetically
6. Provides statistics

### Examples

**Basic Cleaning:**
```bash
subtool -mode clean -i raw-domains.txt -o clean-domains.txt
```

**Verbose Output:**
```bash
subtool -mode clean -i raw-domains.txt -o clean-domains.txt -v
```

**Quiet Mode (No Statistics):**
```bash
subtool -mode clean -i raw-domains.txt -o clean-domains.txt -q
```

**Using stdin/stdout:**
```bash
cat domains.txt | subtool -mode clean -i - -o clean.txt
```

**Output to stdout:**
```bash
subtool -mode clean -i domains.txt -o - > result.txt
```

### Statistics Output

```
=== STATISTICS ===
Total lines:        10,245
Unique subdomains:  8,123
Duplicates removed: 2,122
Invalid entries:    15
Processing time:    234ms
==================
```

## Mode: Filter

Apply advanced filtering rules to subdomain lists.

### Filter Options

| Option | Description | Example |
|--------|-------------|---------|
| `-include` | Include only domains with keywords | `-include api,dev` |
| `-exclude` | Exclude domains with keywords | `-exclude test,old` |
| `-min-length` | Minimum domain length | `-min-length 10` |
| `-max-length` | Maximum domain length | `-max-length 50` |
| `-tld` | Filter by TLD | `-tld com,org` |
| `-no-wildcard` | Remove wildcard entries | `-no-wildcard` |

### Examples

**Include Specific Keywords:**
```bash
# Only domains containing "api" or "dev"
subtool -mode filter -i domains.txt -o api-dev.txt -include api,dev
```

**Exclude Keywords:**
```bash
# Remove test/staging domains
subtool -mode filter -i domains.txt -o production.txt -exclude test,staging,dev
```

**Combined Filters:**
```bash
# Production API endpoints only
subtool -mode filter -i domains.txt -o prod-api.txt \
  -include api,prod \
  -exclude test,staging \
  -tld com \
  -min-length 15
```

**Remove Wildcards:**
```bash
# Clean up subdomain lists with wildcard entries
subtool -mode filter -i domains.txt -o no-wildcards.txt -no-wildcard
```

**Length Filtering:**
```bash
# Only medium-length domains
subtool -mode filter -i domains.txt -o medium.txt \
  -min-length 15 \
  -max-length 40
```

**TLD Filtering:**
```bash
# Only .com, .net, and .org domains
subtool -mode filter -i domains.txt -o main-tlds.txt -tld com,net,org
```

### Filter Validation

The filter mode automatically validates domain format:
- Removes invalid characters
- Checks proper domain structure
- Validates TLD format

## Mode: Analyze

Perform statistical analysis on subdomain datasets.

### What It Analyzes

1. **Root Domain Grouping** - Groups subdomains by their root domain
2. **Depth Analysis** - Analyzes subdomain depth levels (e.g., a.b.c.example.com = depth 3)
3. **Word Frequency** - Extracts and counts common words in subdomains
4. **Pattern Detection** - Finds common prefixes and suffixes

### Examples

**Basic Analysis (Text Report):**
```bash
subtool -mode analyze -i domains.txt -o report.txt
```

**JSON Output:**
```bash
subtool -mode analyze -i domains.txt -format json -o analysis.json
```

**CSV Output:**
```bash
subtool -mode analyze -i domains.txt -format csv -o analysis.csv
```

### Analysis Report Sections

#### 1. Overview
```
OVERVIEW
Total Subdomains: 15,234
Unique Root Domains: 45
Max Depth Level: 5
Average Depth: 2.34
```

#### 2. Top Root Domains
```
TOP 10 ROOT DOMAINS BY SUBDOMAIN COUNT
1. example.com (8,234 subdomains)
2. test.com (3,456 subdomains)
3. demo.org (2,123 subdomains)
```

#### 3. Depth Distribution
```
DEPTH DISTRIBUTION
Depth 1: 234 domains
Depth 2: 8,456 domains
Depth 3: 5,234 domains
Depth 4: 1,234 domains
Depth 5: 76 domains
```

#### 4. Common Words
```
TOP 20 COMMON WORDS
1. api (2,345 occurrences)
2. dev (1,234 occurrences)
3. staging (987 occurrences)
4. prod (876 occurrences)
5. admin (654 occurrences)
```

#### 5. Pattern Analysis
```
COMMON PREFIXES (appearing 5+ times)
  api: 234
  dev: 156
  staging: 98
```

### JSON Analysis Format

```json
{
  "total_subdomains": 15234,
  "root_domains": {
    "example.com": {
      "root_domain": "example.com",
      "subdomains": ["api.example.com", "dev.example.com"],
      "count": 8234
    }
  },
  "depth_analysis": {
    "max_depth": 5,
    "min_depth": 1,
    "avg_depth": 2.34,
    "depth_counts": {
      "1": 234,
      "2": 8456,
      "3": 5234
    }
  },
  "top_words": [
    {"word": "api", "count": 2345},
    {"word": "dev", "count": 1234}
  ]
}
```

## Advanced Workflows

### Bug Bounty Workflow

```bash
# 1. Merge results from multiple tools
cat amass.txt subfinder.txt assetfinder.txt > all-domains.txt

# 2. Clean and deduplicate
subtool -mode clean -i all-domains.txt -o clean-domains.txt

# 3. Remove wildcards and test domains
subtool -mode filter -i clean-domains.txt -o filtered.txt \
  -no-wildcard \
  -exclude test,staging,dev

# 4. Analyze to find interesting patterns
subtool -mode analyze -i filtered.txt -format json -o analysis.json

# 5. Extract specific targets
subtool -mode filter -i filtered.txt -o targets.txt \
  -include api,admin,portal,login
```

### Reconnaissance Pipeline

```bash
# Full pipeline with progress tracking
cat raw-subdomains.txt | \
  subtool -mode clean -i - -o - -v | \
  subtool -mode filter -i - -o - -include prod,api -v | \
  subtool -mode filter -i - -o final-targets.txt -no-wildcard -v
```

### Batch Processing

```bash
# Process multiple files
for file in *.txt; do
  echo "Processing $file..."
  subtool -mode clean -i "$file" -o "clean_$file"
done

# Merge all cleaned files
cat clean_*.txt | subtool -mode clean -i - -o final-merged.txt
```

### Comparison Workflow

```bash
# Before and after comparison
subtool -mode analyze -i before.txt -o before-analysis.json -format json
subtool -mode analyze -i after.txt -o after-analysis.json -format json

# Use jq to compare
jq -s '.[0].total_subdomains - .[1].total_subdomains' \
  before-analysis.json after-analysis.json
```

## Performance Tuning

### Large File Handling

For files > 10M lines:

```bash
# Process in chunks
split -l 1000000 huge-file.txt chunk_

# Parallel processing
for file in chunk_*; do
  subtool -mode clean -i "$file" -o "clean_$file" -q &
done
wait

# Merge results
cat clean_chunk_* | subtool -mode clean -i - -o final.txt
```

### Memory Optimization

```bash
# Use quiet mode to reduce memory overhead
subtool -mode clean -i large.txt -o clean.txt -q

# Stream processing for maximum efficiency
cat large.txt | subtool -mode clean -i - -o - -q > result.txt
```

### Speed Optimization

```bash
# Disable color output for faster processing
subtool -mode clean -i domains.txt -o clean.txt -no-color -q

# Combine operations to reduce I/O
cat domains.txt | \
  subtool -mode clean -i - -o - -q | \
  subtool -mode filter -i - -o final.txt -include api -q
```

## Tips and Tricks

### 1. Quick Deduplication
```bash
subtool -mode clean -i domains.txt -o - | wc -l
```

### 2. Count by Root Domain
```bash
subtool -mode analyze -i domains.txt -format json -o - | \
  jq '.root_domains | length'
```

### 3. Extract Specific Depth
```bash
# Get only depth-3 subdomains (a.b.example.com)
subtool -mode analyze -i domains.txt -format json -o - | \
  jq -r '.depth_analysis.by_depth_level["3"][]'
```

### 4. Find Unique Words
```bash
subtool -mode analyze -i domains.txt -format json -o - | \
  jq -r '.top_words[].word'
```

### 5. Validate Domain List
```bash
# Remove invalid domains
subtool -mode filter -i domains.txt -o valid.txt
```

## Common Use Cases

### Security Testing
```bash
# Extract production APIs
subtool -mode filter -i all-domains.txt -o prod-api.txt \
  -include api,prod \
  -exclude test,dev,staging \
  -tld com
```

### Asset Discovery
```bash
# Find admin panels
subtool -mode filter -i domains.txt -o admin.txt \
  -include admin,panel,dashboard,manage
```

### Scope Reduction
```bash
# Remove out-of-scope domains
subtool -mode filter -i all-domains.txt -o in-scope.txt \
  -exclude *.cdn,*.static,*.img
```

## Troubleshooting

### Issue: "Out of memory"
**Solution:** Process in smaller batches or use streaming

### Issue: "Too slow on large files"
**Solution:** Use `-q` flag and disable color output

### Issue: "Invalid domain format"
**Solution:** Use filter mode to validate and clean

### Issue: "Missing domains in output"
**Solution:** Check if filters are too restrictive

## Getting Help

```bash
# Show help menu
subtool -h

# Show version
subtool -version
```

For more information, visit the GitHub repository or open an issue.
